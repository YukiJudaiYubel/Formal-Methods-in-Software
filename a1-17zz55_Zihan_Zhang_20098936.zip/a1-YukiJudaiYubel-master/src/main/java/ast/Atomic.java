package ast;

public abstract class Atomic extends Formula {
}
