import ast.*;
import ql.QLParser;

import java.util.*;

public class Eval extends BaseEval {
    //-----------------------!! DO NOT MODIFY !!-------------------------
    private int[][] M;
    public Eval(int[][] M) {
        this.M = M;
    }
    //-------------------------------------------------------------------

    @Override
    protected Integer evalNExp(NExp exp, Env env) {
        if (exp instanceof Nat){
            return evalNat((Nat)exp);
        }
        if (exp instanceof SalesAt){
            return evalSalesAt((SalesAt)exp, env);
        }
        if (exp instanceof SalesForP){
            return evalSalesForP((SalesForP)exp, env);
        }
        if (exp instanceof SalesForD){
            return evalSalesForD((SalesForD)exp, env);
        }
        if (exp instanceof SalesForM){
            return evalSalesForM((SalesForM)exp, env);
        }
        if (exp instanceof Size){
            return evalSize((Size)exp, env);
        }
        if (exp instanceof BinaryNExp){
            return evalBinaryNExp((BinaryNExp)exp, env);
        }
        if (exp instanceof Var){
            return evalVar((Var)exp, env);
        }
        return 0;
    }

    public Integer evalNat(Nat exp){
        return exp.value;
    }

    public Integer evalVar(Var exp, Env env){
        if (env.lookup(exp.name) != -1){
            return env.lookup(exp.name);
        }
        else{
            throw new UnboundVariableException();
        }
    }

    public Integer evalSalesAt(SalesAt exp, Env env){
        int prod = evalNExp(exp.product, env)-1;
        int day  = evalNExp(exp.day, env)-1;
        int SA = M[prod][day];
        return SA;
    }

    public Integer evalSalesForP(SalesForP exp, Env env){
        int prod  = evalNExp(exp.product, env)-1;
        int psales = 0;
        for (int i = 0; i<M[0].length; i++){
            psales = psales+ M[prod][i];
        }
        return psales;
    }

    public Integer evalSalesForD(SalesForD exp, Env env){
        int day  = evalNExp(exp.day, env)-1;
        int dsales = 0;
        for (int i = 0; i<M.length; i++){
            dsales = dsales+ M[i][day];
        }
        return dsales;
    }

    public Integer evalSalesForM(SalesForM exp, Env env){
        int msales = 0;
        for (int i = 0; i<M.length; i++){
            for (int j = 0; j<M[0].length; j++){
                msales = msales+ M[i][j];
            }
        }
        return msales;
    }

    public Integer evalSize(Size exp, Env env){
        SExp input = exp.sExp;
        int S = evalSExp(input, env).size();
        return S;
    }

    public Integer evalBinaryNExp(BinaryNExp exp, Env env){
        int first = evalNExp(exp.lhs, env);
        int second = evalNExp(exp.rhs, env);
        if (exp.op.kind == BinNOp.ADD().kind){
            return first+second;
        }
        if (exp.op.kind == BinNOp.DIFF().kind){
            return first-second;
        }
        if (exp.op.kind == BinNOp.MULT().kind){
            return first*second;
        }
        if (exp.op.kind == BinNOp.DIV().kind){
            if (second != 0){
                return first/second;
            }
            else{
                throw new DivisionByZeroException();
            }
        }
        return null;
    }

    @Override
    protected Set<Integer> evalSExp(SExp Sexp, Env en) {
        if (Sexp instanceof Type){
            return evalType((Type)Sexp, en);
        }
        if (Sexp instanceof BinarySExp){
            return evalBinarySExp((BinarySExp)Sexp, en);
        }
        if (Sexp instanceof SetCompr){
            return evalSetCompr((SetCompr)Sexp, en);
        }
        return null;
    }

    public Set evalType(Type Sexp, Env en){
        Set<Integer>  dis= new HashSet<Integer>();
        if (Sexp.kind == Type.DAY().kind){
            for (int i = 0; i<M[0].length; i++){
                dis.add(i+1);
            }
        }
        if (Sexp.kind == Type.PRODUCT().kind){
            for (int i = 0; i<M.length; i++){
                dis.add(i+1);
            }
        }
        if (Sexp.kind == Type.SALE().kind){
            for (int i = 0; i<M.length; i++){
                for (int j = 0; j<M[0].length; j++){
                    dis.add(M[i][j]);
                }
            }
        }
        return dis;
    }

    public Set evalBinarySExp(BinarySExp Sexp, Env en){
        Set first = evalSExp(Sexp.lhs, en);
        Set second = evalSExp(Sexp.rhs, en);
        Set<Integer> result = new HashSet<Integer>(first);
        if (Sexp.op.kind == BinSOp.UNION().kind){
            result.addAll(second);
            return result;
        }
        if (Sexp.op.kind == BinSOp.DIFF().kind){
            result.removeAll(second);
            return result;
        }
        if (Sexp.op.kind == BinSOp.INTER().kind){
            result.retainAll(second);
            return result;
        }
        return null;
    }

    public Set evalSetCompr(SetCompr Sexp, Env en){
        Set<Integer> dis= new HashSet<Integer>();
        Set<Integer> Objects = evalSExp(Sexp.type, en);
        Iterator <Integer> iter = Objects.iterator();
        while (iter.hasNext()){
            en.push(Sexp.var.name, iter.next());
            if (evalFormula(Sexp.formula, en)){
                dis.add(evalNExp(Sexp.var, en));
            }
        }
        System.out.println(dis);
        return dis;
    }


    @Override
    protected Boolean evalFormula(Formula f, Env e) {
        if (f instanceof AtomicS){
            return evalAtomicS((AtomicS)f, e);
        }
        if (f instanceof AtomicN){
            return evalAtomicN((AtomicN)f, e);
        }
        if (f instanceof Unary){
            return evalUnary((Unary)f, e);
        }
        if (f instanceof Binary){
            return evalBinary((Binary)f, e);
        }
        if (f instanceof Quantified){
            return evalQuantified((Quantified)f, e);
        }
        return false;
    }

    public Boolean evalAtomicS(AtomicS f, Env e) {
        Set first = evalSExp(f.lhs, e);
        Set second = evalSExp(f.rhs, e);
        if (f.relSOp.kind == RelSOp.EQ().kind) {
            if ((first.containsAll(second))&&(second.containsAll(first))){
                return true;
            }
        }
        return false;
    }

    public Boolean evalAtomicN(AtomicN f, Env e){
        Integer first = evalNExp(f.lhs, e);
        Integer second = evalNExp(f.rhs, e);
        if (f.relNOp.kind == RelNOp.EQ().kind){
            if (first == second){
                return true;
            }
        }
        if (f.relNOp.kind == RelNOp.NEQ().kind){
            if (first != second){
                return true;
            }
        }
        if (f.relNOp.kind == RelNOp.LT().kind){
            if (first < second){
                return true;
            }
        }
        if (f.relNOp.kind == RelNOp.LTE().kind){
            if (first <= second){
                return true;
            }
        }
        if (f.relNOp.kind == RelNOp.GT().kind){
            if (first > second){
                return true;
            }
        }
        if (f.relNOp.kind == RelNOp.GTE().kind){
            if (first >= second){
                return true;
            }
        }
        return false;
    }

    public Boolean evalUnary(Unary f, Env e){
        Boolean result = evalFormula(f.formula, e);
        if (f.unConn.kind == UnaryConn.NOT().kind) {
            return !result;
        }
        return false;
    }

    public Boolean evalBinary(Binary f, Env e) {
        Boolean first = evalFormula(f.lhs, e);
        Boolean second = evalFormula(f.rhs, e);
        if (f.binConn.kind == BinaryConn.AND().kind) {
            return (first&&second);
        }
        if (f.binConn.kind == BinaryConn.OR().kind) {
            return (first||second);
        }
        if (f.binConn.kind == BinaryConn.IMPLY().kind) {
            if ((first.equals(true))&&(second.equals(false))) {
                return false;
            } else {
                return true;
            }
        }
        if (f.binConn.kind == BinaryConn.EQUIV().kind) {
            if (first.equals(second)) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public boolean evalQuantified(Quantified f, Env e) {
        Set<Integer> Objects = evalSExp(f.type, e);
        if (f.quantifier.kind == Quantifier.Kind.FORALL){
            Iterator <Integer> iter = Objects.iterator();
            while (iter.hasNext()){
                e.push(f.var.name, iter.next());
                if (!evalFormula(f.formula, e)){
                    return false;
                }
            }
            return true;
        }
        if (f.quantifier.kind == Quantifier.Kind.EXISTS){
            Iterator <Integer> iter = Objects.iterator();
            while (iter.hasNext()){
                e.push(f.var.name, iter.next());
                if (evalFormula(f.formula, e)){
                    return true;
                }
            }
        }
        return false;
    }

}
